using System;

namespace StudentMarksheet;

public class TheoryExamMarks : PersonalInfo
{
    public int[] Sem1 = new int[6];
    public int[] Sem2 = new int[6];
    public int[] Sem3 = new int[6];
    public int[] Sem4 = new int[6];
}
