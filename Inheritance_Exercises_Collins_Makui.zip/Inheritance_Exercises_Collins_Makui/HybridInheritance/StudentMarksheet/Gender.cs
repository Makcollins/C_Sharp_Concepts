namespace StudentMarksheet;

public enum Gender
{
    Male,Female
}
