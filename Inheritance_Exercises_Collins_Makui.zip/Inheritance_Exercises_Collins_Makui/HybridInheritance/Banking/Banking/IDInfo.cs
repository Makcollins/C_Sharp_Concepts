using System;

namespace Banking;

public class IDInfo : PersonalInfo
{
    public string? VoterID { get; set; }
    public string? AadharID { get; set; }
    public string? PANNumber { get; set; }
}
