namespace Banking;

public enum Gender
{
    Male,Female
}
