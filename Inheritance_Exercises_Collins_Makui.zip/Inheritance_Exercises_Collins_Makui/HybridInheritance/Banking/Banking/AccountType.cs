namespace Banking;

public enum AccountType
{
    Savings,Balance
}
