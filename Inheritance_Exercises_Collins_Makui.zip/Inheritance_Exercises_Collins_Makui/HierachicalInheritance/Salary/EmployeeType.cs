namespace Salary;

public enum EmployeeType
{
    Permanent, Temporary
}
