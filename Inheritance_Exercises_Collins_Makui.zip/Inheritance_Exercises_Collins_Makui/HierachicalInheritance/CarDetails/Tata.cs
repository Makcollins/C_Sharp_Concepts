using System;

namespace CarDetails;

public class Tata : CarInfo
{
    public string? CarModelNumber { get; set; }
    public string? CarModelName { get; set; }
}
