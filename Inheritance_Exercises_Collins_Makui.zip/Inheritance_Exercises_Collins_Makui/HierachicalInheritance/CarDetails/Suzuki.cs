using System;

namespace CarDetails;

public class Suzuki : CarInfo
{
    public string? CarModelNumber { get; set; }
    public string? CarModelName { get; set; }
}
