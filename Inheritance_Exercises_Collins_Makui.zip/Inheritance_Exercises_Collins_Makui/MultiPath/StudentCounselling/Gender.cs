namespace StudentCounselling;

public enum Gender
{
    Male,Female
}
