using System;

namespace CarModels;

public interface IBrand
{
string BrandName { get; set; }
string ModelName { get; set; }
}
