namespace Student;

public enum Gender
{
Male,Female
}
