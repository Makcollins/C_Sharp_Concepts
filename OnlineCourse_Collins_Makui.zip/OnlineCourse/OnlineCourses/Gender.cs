namespace OnlineCourses;

public enum Gender
{
Male, Female, Transgender
}