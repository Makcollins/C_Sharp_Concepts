using System;

namespace OnlineHospital;

public class SlotDetails
{
    public string? DoctorID { get; set; }
    public string? SlotID { get; set; }
    public string? SlotTime { get; set; }
}
