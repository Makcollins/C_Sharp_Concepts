using System;

namespace OnlineHospital;

public class PersonalDetails
{
    public string? Name { get; set; }
    public string? FatherName { get; set; }
    public Gender Gender { get; set; }
    public string? Phone { get; set; }
    public int Age { get; set; }
}
