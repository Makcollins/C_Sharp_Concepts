namespace OnlineHospital;

public enum Gender
{
    Male,Female,Transgender
}
