using GroupManager.Data;
using GroupManager.DTOs;
using GroupManager.Interfaces;
using GroupManager.Models;
using Microsoft.EntityFrameworkCore;
using NSCore.DatabaseContext;
using NSCore.SearchOption;
using NSCore.Validation;
using NSEncryption;
using static GroupManager.Data.AppDbContextVariants;

namespace GroupManager.DbImplementation;

public class MySQL : IManageGroups , INsContextInit
{
    private bool _disposed = false;
    private readonly string _connectionString;
    private readonly MySQLGroupManagerDbContext _context;

    public MySQL(string connectionString)
    {
        _connectionString = connectionString;
        var optionsBuilder = new DbContextOptionsBuilder<GroupManagerDbContext>();
        var serverVersion = new MySqlServerVersion(new Version(8, 0, 3));
        optionsBuilder.UseMySql(connectionString, serverVersion);

        try
        {
            _context = new MySQLGroupManagerDbContext(optionsBuilder.Options);

            // Check if the database can be connected
            if (!_context.Database.CanConnect())
            {
                throw new InvalidOperationException("Unable to connect to the database. Please check the connection string and database server.");
            }
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("Failed to initialize the database context.", ex);
        }
    }

    /// <inheritdoc/>
    public async Task ApplyMigrationsAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            var canConnect = await _context.Database.CanConnectAsync();
            if (!canConnect)
            {
                throw new InvalidOperationException("Database doesn't exist. Please create and configure it first.");
            }

            var appliedMigrations = await _context.Database.GetAppliedMigrationsAsync(cancellationToken);
            var pendingMigrations = await _context.Database.GetPendingMigrationsAsync(cancellationToken);

            if (pendingMigrations.Any())
            {
                await _context.Database.MigrateAsync(cancellationToken);
            }
        }
        catch (Exception ex) when (IsTableAlreadyExistsError(ex))
        {
            await HandleMigrationConflictAsync(cancellationToken);
        }
        catch (Exception ex)
        {
            throw new Exception($"Migration failed: {ex.Message}", ex);
        }
    }

    private async Task MarkMigrationAsAppliedAsync(string migrationId, CancellationToken cancellationToken)
    {
        try
        {
            var provider = _context.Database.ProviderName;
            var productVersion = typeof(DbContext).Assembly.GetName().Version?.ToString() ?? "8.0.0";

            string sql;
            object[] parameters;

            if (provider.Contains("MySql"))
            {
                sql = @"
                INSERT IGNORE INTO `__EFMigrationsHistory` (`MigrationId`, `ProductVersion`)
                VALUES (@migrationId, @productVersion);";
                parameters = new[]
                {
                new MySqlConnector.MySqlParameter("@migrationId", migrationId),
                new MySqlConnector.MySqlParameter("@productVersion", productVersion)
            };
            }
            else
            {
                throw new NotSupportedException($"Unsupported database provider: {provider}");
            }

            await _context.Database.ExecuteSqlRawAsync(sql, parameters, cancellationToken);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to mark migration {migrationId} as applied: {ex.Message}", ex);
        }
    }

    private bool IsTableAlreadyExistsError(Exception ex)
    {
        if (ex is MySqlConnector.MySqlException mysqlEx && mysqlEx.Number == 1050)
            return true;

        return false;
    }

    private async Task HandleMigrationConflictAsync(CancellationToken cancellationToken)
    {
        try
        {
            var allMigrations = _context.Database.GetMigrations().ToList();
            var pendingMigrations = await _context.Database.GetPendingMigrationsAsync(cancellationToken);
            var latestMigration = allMigrations.LastOrDefault();

            if (latestMigration != null && pendingMigrations.Contains(latestMigration))
            {
                foreach (var migration in pendingMigrations)
                {
                    await MarkMigrationAsAppliedAsync(migration, cancellationToken);
                }
            }
            else
            {
                throw new InvalidOperationException("Could not resolve conflict: No valid latest migration found.");
            }
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to resolve migration conflict: {ex.Message}", ex);
        }
    }

    /// <inheritdoc/>
    public bool IsContextCreated()
    {
        try
        {
            return _context.Database.CanConnect();
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("Failed to check if the context is created.", ex);
        }
    }

    /// <inheritdoc/>
    public async Task<(IEnumerable<GroupModel> Groups, int TotalCount)> SearchGroupsAsync(
        string? searchTerm = null,
        string? sortBy = "Name",
        bool ascending = true,
        int pageNumber = 1,
        int pageSize = 10,
        string searchMode = "contains"
        )
    {
        if (pageNumber <= 0)
            throw new ArgumentException("Page number must be greater than zero.", nameof(pageNumber));

        if (pageSize <= 0)
            throw new ArgumentException("Page size must be greater than zero.", nameof(pageSize));

        try
        {
            // var query = _context.Users.Include(u => u.Metadata).AsQueryable();
            var query = _context.Groups.AsQueryable();

            query = query.ApplySearch(searchTerm, searchMode, g => g.Name, g => g.Description);

            var totalCount = await query.CountAsync();

            query = query.ApplySort(sortBy, ascending, "Name")
                         .ApplyPagination(pageNumber, pageSize);

            var groups = await query.ToListAsync();

            return (groups, totalCount);
        }
        catch (DbUpdateException dbEx)
        {
            throw new InvalidOperationException("A database error occurred while searching for users.", dbEx);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An error occurred while searching for users.", ex);
        }
    }

    /// <inheritdoc/>
    public async Task CreateUserAsync(string userName, string email, string password)
    {
        try
        {
            InputValidator.Validate([userName, email, password]);
            var hasher = new Hasher(12);

            // Check for duplicate email
            if (await _context.Users.AnyAsync(u => u.Email == email))
                throw new InvalidOperationException("A user with this email already exists.");

            var user = new UserModel
            {
                UserName = userName,
                Email = email,
                Password = hasher.GenerateHashPassword(password),
                RegisteredAt = DateTimeOffset.UtcNow
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception("Failed to create user", ex);
        }
    }

    /// <inheritdoc/>
    public async Task CreateUserAsync(CreateUserDto userDto)
    {
        try
        {
            InputValidator.Validate([userDto.UserName, userDto.Email, userDto.Password]);
            var hasher = new Hasher(12);

            if (await _context.Users.AnyAsync(u => u.Email.ToLower() == userDto.Email.ToLower()))
            {
                throw new InvalidOperationException("A user with this email already exists.");
            }

            if (await _context.Users.AnyAsync(u => u.UserName == userDto.UserName))
            {
                throw new InvalidOperationException("A user with this username already exists.");
            }

            var user = new UserModel
            {
                UserName = userDto.UserName,
                Email = userDto.Email,
                Password = hasher.GenerateHashPassword(userDto.Password),
                RegisteredAt = DateTimeOffset.UtcNow
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception("Failed to create user", ex);
        }
    }

    /// <inheritdoc/>
    public async Task CreateUsersAsync(List<CreateUserDto> users)
    {
        try
        {
            if (users == null || users.Count == 0)
            {
                throw new Exception("List of users cannot be empty");
            }

            var hasher = new Hasher(12);
            var userEntities = new List<UserModel>();

            foreach (var user in users)
            {
                InputValidator.Validate([user.UserName, user.Email, user.Password]);

                if (await _context.Users.AnyAsync(u => u.Email.ToLower() == user.Email.ToLower()))
                {
                    throw new InvalidOperationException($"User with email {user.Email} already exists.");
                }

                if (await _context.Users.AnyAsync(u => u.UserName == user.UserName))
                {
                    throw new InvalidOperationException($"User with username {user.UserName} already exists.");
                }

                userEntities.Add(new UserModel
                {
                    UserName = user.UserName,
                    Email = user.Email,
                    Password = hasher.GenerateHashPassword(user.Password),
                    RegisteredAt = DateTimeOffset.UtcNow
                });
            }

            _context.Users.AddRange(userEntities);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {

            throw new Exception("Failed to create multiple users", ex);
        }
    }

    /// <inheritdoc/>
    public async Task CreateGroupAsync(string name, int createdByUserId, string? description = null, string? category = null, string? profilePicture = null)
    {
        try
        {
            InputValidator.Validate(name);
            var user = await _context.Users.FindAsync(createdByUserId);
            if (user == null)
            {
                throw new ArgumentException($"User with ID {createdByUserId} does not exist.");
            }

            var group = new GroupModel
            {
                Name = name,
                Description = description ?? string.Empty,
                ProfilePicture = profilePicture ?? string.Empty,
                CreatedAt = DateTimeOffset.UtcNow,
                IsActive = true,
                IsArchived = false,
                IsVerified = false,
                LastActivityAt = DateTimeOffset.UtcNow,
                Category = category ?? string.Empty,
                CreatedByUserId = createdByUserId,
                CreatedBy = user
            };

            _context.Groups.Add(group);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            // Optionally log here
            throw new ApplicationException("Failed to create group", ex);
        }
    }


    /// <inheritdoc/>
    public async Task CreateGroupAsync(CreateGroupDto groupDto)
    {
        try
        {
            InputValidator.Validate(groupDto.Name);

            var user = await _context.Users.FindAsync(groupDto.CreatedByUserId);
            if (user == null)
            {
                throw new ArgumentException($"User with ID {groupDto.CreatedByUserId} does not exist.");
            }

            var group = new GroupModel
            {
                Name = groupDto.Name,
                Description = groupDto.Description ?? string.Empty,
                ProfilePicture = groupDto.ProfilePicture ?? string.Empty,
                CreatedAt = DateTimeOffset.UtcNow,
                IsActive = true,
                IsArchived = false,
                IsVerified = false,
                LastActivityAt = DateTimeOffset.UtcNow,
                Category = groupDto.Category ?? string.Empty,
                CreatedByUserId = groupDto.CreatedByUserId,
                CreatedBy = user
            };

            _context.Groups.Add(group);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception("Failed to create group", ex);
        }
    }

    /// <inheritdoc/>
    public async Task CreateGroupsAsync(List<CreateGroupDto> groups)
    {
        try
        {
            if (groups == null || groups.Count == 0)
            {
                throw new Exception("List of groups cannot be empty");
            }

            var userIds = groups.Select(g => g.CreatedByUserId).Distinct().ToList();
            var existingUsers = await _context.Users.Where(u => userIds.Contains(u.Id)).ToDictionaryAsync(u => u.Id);

            var groupEntities = new List<GroupModel>();

            foreach (var group in groups)
            {
                InputValidator.Validate(group.Name);

                if (!existingUsers.TryGetValue(group.CreatedByUserId, out var user))
                {
                    throw new Exception($"User with ID {group.CreatedByUserId} does not exist.");
                }

                groupEntities.Add(new GroupModel
                {
                    Name = group.Name,
                    Description = group.Description ?? string.Empty,
                    ProfilePicture = group.ProfilePicture ?? string.Empty,
                    CreatedAt = DateTimeOffset.UtcNow,
                    IsActive = true,
                    IsArchived = false,
                    IsVerified = false,
                    LastActivityAt = DateTimeOffset.UtcNow,
                    Category = group.Category ?? string.Empty,
                    CreatedByUserId = group.CreatedByUserId,
                    CreatedBy = user
                });
            }

            _context.Groups.AddRange(groupEntities);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception("Failed to create multiple groups", ex);
        }
    }

    /// <inheritdoc/>
    public async Task CreateGroupsAsync(int userId, List<CreateGroupDto> groups)
    {
        try
        {
            if (groups == null || groups.Count == 0)
                throw new ArgumentException("List of groups cannot be empty.");

            var user = await _context.Users.FindAsync(userId);
            if (user == null)
                throw new Exception($"User with ID {userId} does not exist.");

            var groupEntities = new List<GroupModel>();

            foreach (var group in groups)
            {
                InputValidator.Validate(group.Name);

                groupEntities.Add(new GroupModel
                {
                    Name = group.Name,
                    Description = group.Description ?? string.Empty,
                    ProfilePicture = group.ProfilePicture ?? string.Empty,
                    CreatedAt = DateTimeOffset.UtcNow,
                    IsActive = true,
                    IsArchived = false,
                    IsVerified = false,
                    LastActivityAt = DateTimeOffset.UtcNow,
                    Category = group.Category ?? string.Empty,
                    CreatedByUserId = userId,
                    CreatedBy = user
                });
            }

            _context.Groups.AddRange(groupEntities);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception("Failed to create multiple groups", ex);
        }
    }

    /// <inheritdoc/>
    public async Task<GroupModel?> GetGroupByIdAsync(int groupId)
    {
        try
        {
            return await _context.Groups
                .Include(g => g.GroupUsers)
                .FirstOrDefaultAsync(g => g.Id == groupId);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to get group with ID {groupId}", ex);
        }
    }

    /// <inheritdoc/>
    public Task<UserModel?> GetUserByIdAsync(int userId)
    {
        try
        {
            return _context.Users
                .Include(u => u.GroupUsers)
                .FirstOrDefaultAsync(u => u.Id == userId);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to get user with ID {userId}", ex);
        }
    }

    /// <inheritdoc/>
    public async Task AddUserToGroupAsync(int userId, int groupId)
    {
        try
        {
            var user = await _context.Users.FindAsync(userId);
            var group = await _context.Groups.FindAsync(groupId);

            if (user == null || group == null)
                throw new InvalidOperationException("User or group not found.");

            bool alreadyInGroup = await _context.Set<GroupUser>()
                .AnyAsync(gu => gu.UserId == userId && gu.GroupId == groupId);
            
            if (alreadyInGroup)
                throw new InvalidOperationException("User is already a member of this group.");

            var groupUser = new GroupUser
            {
                UserId = userId,
                GroupId = groupId
            };

            group.UpdatedAt = DateTime.UtcNow;
            group.LastActivityAt = DateTimeOffset.UtcNow;

            _context.Set<GroupUser>().Add(groupUser);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to add user with ID {userId} to group with ID {groupId}", ex);
        }
    }

    /// <inheritdoc/>
    public async Task AddUsersToGroupAsync(List<int> userIds, int groupId)
    {
        if (userIds == null || userIds.Count == 0)
            throw new ArgumentException("List of user IDs cannot be empty", nameof(userIds));

        var group = await _context.Groups.FindAsync(groupId);
        if (group == null)
            throw new Exception($"Group with ID {groupId} not found");

        var existingUserIds = await _context.Set<GroupUser>().Where(gu => gu.GroupId == groupId && userIds.Contains(gu.UserId)).Select(gu => gu.UserId).ToListAsync();
        var validUsers = await _context.Users.Where(u => userIds.Contains(u.Id)).ToListAsync();
        var foundUserIds = validUsers.Select(u => u.Id).ToList();
        var missingUserIds = userIds.Except(foundUserIds).ToList();

        if (missingUserIds.Any())
            throw new InvalidOperationException($"Users with IDs {string.Join(", ", missingUserIds)} not found");

        var usersToAdd = foundUserIds.Except(existingUserIds).ToList();
        if (usersToAdd.Count == 0)
            throw new InvalidOperationException("All users are already members of the group");

        var groupUsers = usersToAdd.Select(uid => new GroupUser
        {
            UserId = uid,
            GroupId = groupId
        });

        group.UpdatedAt = DateTime.UtcNow;
        group.LastActivityAt = DateTimeOffset.UtcNow;

        _context.Set<GroupUser>().AddRange(groupUsers);

        await _context.SaveChangesAsync();
    }


    /// <inheritdoc/>
    public async Task UpdateGroupAsync(UpdateGroupDto group, int groupId)
    {
        if (group == null) throw new Exception("Group cannot be null");
        try
        {
            var existingGroup = await _context.Groups.FindAsync(groupId);
            if (existingGroup == null)
                throw new InvalidOperationException("Group not found.");

            existingGroup.Name = group.Name ?? existingGroup.Name;
            existingGroup.Description = group.Description ?? existingGroup.Description;
            existingGroup.ProfilePicture = group.ProfilePicture ?? existingGroup.ProfilePicture;
            existingGroup.UpdatedAt = DateTimeOffset.UtcNow;
            existingGroup.LastActivityAt = DateTimeOffset.UtcNow;
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception("Failed to update group", ex);
        }
    }

    /// <inheritdoc/>
    public async Task UpdateGroupsAsync(List<BulkUpdateGroupDto> updatedGroups)
    {
        if (updatedGroups == null)
            throw new ArgumentNullException(nameof(updatedGroups));

        if (updatedGroups.Count == 0)
            throw new ArgumentException("Group list cannot be empty", nameof(updatedGroups));

        try
        {
            var groupIds = updatedGroups.Select(g => g.Id).ToList();
            var existingGroups = await _context.Groups
                .Where(g => groupIds.Contains(g.Id))
                .ToListAsync();

            var groupMap = updatedGroups.ToDictionary(g => g.Id);

            foreach (var group in existingGroups)
            {
                if (groupMap.TryGetValue(group.Id, out var updatedGroup))
                {
                    group.Name = updatedGroup.Name ?? group.Name;
                    group.Description = updatedGroup.Description ?? group.Description;
                    group.ProfilePicture = updatedGroup.ProfilePicture ?? group.ProfilePicture;
                    group.UpdatedAt = DateTimeOffset.UtcNow;
                    group.LastActivityAt = DateTimeOffset.UtcNow;
                }
            }

            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception("Failed to update multiple groups", ex);
        }
    }

    /// <inheritdoc/>
    public async Task UpdateUserAsync(UpdateUserDto user, int userId)
    {
        if (user == null)
            throw new ArgumentNullException(nameof(user), "User cannot be null");

        var hasher = new Hasher(12);

        try
        {
            var existingUser = await _context.Users.FindAsync(userId);
            if (existingUser == null)
                throw new InvalidOperationException("User not found.");

            existingUser.UserName = user.UserName ?? existingUser.UserName;
            existingUser.Email = user.Email ?? existingUser.Email;
            existingUser.Password = hasher.GenerateHashPassword(user.Password) ?? existingUser.Password;
            existingUser.UpdatedAt = DateTimeOffset.UtcNow;
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception("Failed to update user", ex);
        }
    }

    /// <inheritdoc/>
    public async Task UpdateUsersAsync(List<BulkUpdateUserDto> updatedUsers)
    {
        if (updatedUsers == null)
            throw new ArgumentNullException(nameof(updatedUsers));

        if (updatedUsers.Count == 0)
            throw new ArgumentException("User list cannot be empty", nameof(updatedUsers));

        var hasher = new Hasher(12);

        try
        {
            var userIds = updatedUsers.Select(u => u.Id).ToList();
            var existingUsers = await _context.Users
                .Where(u => userIds.Contains(u.Id))
                .ToListAsync();

            var userMap = updatedUsers.ToDictionary(u => u.Id);

            foreach (var user in existingUsers)
            {
                if (userMap.TryGetValue(user.Id, out var updatedUser))
                {
                    user.UserName = updatedUser.UserName ?? user.UserName;
                    user.Email = updatedUser.Email ?? user.Email;
                    user.Password = hasher.GenerateHashPassword(updatedUser.Password) ?? user.Password;
                    user.UpdatedAt = DateTimeOffset.UtcNow;
                }
            }

            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception("Failed to update multiple users", ex);
        }
    }

    /// <inheritdoc/>
    public async Task DeleteGroupAsync(int groupId)
    {
        try
        {
            var group = await _context.Groups.FindAsync(groupId);
            if (group == null)
                throw new InvalidOperationException("Group not found.");
            _context.Groups.Remove(group);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to delete group with ID {groupId}", ex);
        }
    }

    /// <inheritdoc/>
    public async Task DeleteGroupsAsync(List<int> groupIds)
    {

        if (groupIds == null || groupIds.Count == 0)
            throw new ArgumentException("List of group IDs cannot be empty", nameof(groupIds));
        try
        {
            var groupsToDelete = await _context.Groups.Where(g => groupIds.Contains(g.Id)).ToListAsync();
            var missingIds = groupIds.Except(groupsToDelete.Select(g => g.Id)).ToList();
            if (missingIds.Any())
                throw new InvalidOperationException($"Groups with IDs {string.Join(", ", missingIds)} not found");

            _context.RemoveRange(groupsToDelete);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception("Failed to delete groups", ex);
        }
    }

    /// <inheritdoc/>
    public async Task DeleteUserAsync(int userId)
    {
        try
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
                throw new ArgumentException("User not found.", nameof(user));

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to delete user with ID {userId}", ex);
        }
    }

    /// <inheritdoc/>
    public async Task DeleteUsersAsync(List<int> userIds)
    {
        if (userIds == null)
            throw new ArgumentNullException(nameof(userIds));

        if (userIds.Count == 0)
            throw new ArgumentException("List of user IDs cannot be empty", nameof(userIds));

        try
        {
            var usersToDelete = await _context.Users.Where(u => userIds.Contains(u.Id)).ToListAsync();
            var missingIds = userIds.Except(usersToDelete.Select(u => u.Id)).ToList();
            if (!missingIds.Any())
                throw new Exception($"Failed to delete users with IDs {string.Join(", ", missingIds)} not found");

            _context.RemoveRange(usersToDelete);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception("Failed to delete users", ex);
        }
    }

    /// <inheritdoc/>
    public async Task RemoveUserFromGroupAsync(int userId, int groupId)
    {
        try
        {
            var groupUser = await _context.Set<GroupUser>()
           .FirstOrDefaultAsync(gu => gu.UserId == userId && gu.GroupId == groupId);

            if (groupUser == null)
                throw new InvalidOperationException("User is not a member of this group.");


            var group = await _context.Groups
                .FirstOrDefaultAsync(g => g.Id == groupId);

            if (group == null)
                throw new InvalidOperationException("Group not found.");

            _context.Set<GroupUser>().Remove(groupUser);

            group.UpdatedAt = DateTime.UtcNow;
            group.LastActivityAt = DateTimeOffset.UtcNow;

            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to remove user with ID {userId} from group with ID {groupId}", ex);
        }
    }

    /// <inheritdoc/>
    public async Task RemoveUsersFromGroupAsync(List<int> userIds, int groupId)
    {
        if (userIds == null)
            throw new ArgumentNullException(nameof(userIds));

        if (userIds.Count == 0)
            throw new ArgumentException("List of user IDs cannot be empty", nameof(userIds));

        try
        {
            var group = await _context.Groups.FindAsync(groupId);
            if (group == null)
                throw new Exception($"Group with ID {groupId} not found");

            var existingUserIds = await _context.Users.Where(u => userIds.Contains(u.Id)).Select(u => u.Id).ToListAsync();
            var missingUserIds = userIds.Except(existingUserIds).ToList();

            if (missingUserIds.Any())
                throw new InvalidOperationException($"Users with IDs {string.Join(", ", missingUserIds)} not found");

            var groupUsersToRemove = await _context.Set<GroupUser>().Where(gu => gu.GroupId == groupId && userIds.Contains(gu.UserId)).ToListAsync();
            if (!groupUsersToRemove.Any())
                throw new InvalidOperationException("None of the specified users are in the group");

            // Remove the relationships
            _context.Set<GroupUser>().RemoveRange(groupUsersToRemove);

            group.UpdatedAt = DateTime.UtcNow;
            group.LastActivityAt = DateTimeOffset.UtcNow;

            await _context.SaveChangesAsync();
        }
        catch (Exception ex) { throw new Exception("Failed to remove multiple users from the group", ex); }
    }

    /// <inheritdoc/>
    public async Task<List<GroupResponseDto>> GetGroupsByUserId(int userId)
    {
        try
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
            {
                throw new Exception($"User with ID {userId} not found");
            }

            return await _context.GroupUsers
             .Where(gu => gu.UserId == userId)
             .Select(gu => new GroupResponseDto
             {
                 Name = gu.Group.Name,
                 Description = gu.Group.Description
             })
             .ToListAsync();
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to retrieve groups for user with ID {userId}", ex);
        }
    }

    /// <inheritdoc/>
    public async Task<List<UserResponseDto>> GetUsersByGroupId(int groupId)
    {
        try
        {
            var group = await _context.Groups.FindAsync(groupId);
            if (group == null)
            {
                throw new Exception($"Group with ID {groupId} not found");
            }

            return await _context.GroupUsers
            .Where(gu => gu.GroupId == groupId)
            .Select(gu => new UserResponseDto
            {
                UserName = gu.User.UserName,
                Email = gu.User.Email
            })
            .ToListAsync();
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to retrieve users for group with ID {groupId}", ex);
        }
    }

    /// <inheritdoc/>
    public async Task<List<GroupModel>> GetAllGroupsAsync()
    {
        try
        {
            return await _context.Groups.Include(g => g.GroupUsers).ToListAsync();
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to retrieve all groups", ex);
        }
    }

    /// <inheritdoc/>
    public async Task<List<UserModel>> GetAllUsersAsync()
    {
        try
        {
            return await _context.Users.Include(g => g.GroupUsers).ToListAsync();
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to retrieve all users", ex);
        }
    }

    /// <inheritdoc/>
    public async Task<int> GetUserCountAsync()
    {
        try
        {
            return await _context.Users.CountAsync();
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to get user count", ex);
        }
    }

    /// <inheritdoc/>
    public async Task<int> GetGroupCountAsync()
    {
        try
        {
            return await _context.Groups.CountAsync();
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to get group count", ex);
        }
    }

    /// <inheritdoc/>
    public async Task<int> GetUsersCountPerGroupAsync(int groupId)
    {
        try
        {
            if (!await _context.Groups.AnyAsync(g => g.Id == groupId))
            {
                throw new Exception($"Group with ID {groupId} not found");
            }

            return await _context.GroupUsers.CountAsync(gu => gu.GroupId == groupId);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to get user count for group with ID {groupId}", ex);
        }
    }

    /// <inheritdoc/>
    public async Task<int> GetUserGroupCountAsync(int userId)
    {
        try
        {
            var user = await _context.Users
           .Include(u => u.GroupUsers)
           .FirstOrDefaultAsync(u => u.Id == userId);

            if (user == null)
            {
                throw new Exception($"User with ID {userId} not found");
            }

            return user.GroupUsers.Count;
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to get group count for user with ID {userId}", ex);
        }
    }
}
