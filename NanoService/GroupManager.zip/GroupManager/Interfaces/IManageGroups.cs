using GroupManager.DTOs;
using GroupManager.Models;
using System;
using System.Runtime.Intrinsics.X86;

namespace GroupManager.Interfaces;

public interface IManageGroups
{
    /// <summary>
    /// Searches for user groups based on the provided criteria.
    /// </summary>
    /// <param name="searchTerm">Optional term to search for in group names or other fields, depending on the search mode.</param>
    /// <param name="sortBy">The property name to sort the results by. Default is "Name".</param>
    /// <param name="ascending">Indicates whether to sort in ascending order. Default is true.</param>
    /// <param name="pageNumber">The page number to retrieve for paginated results. Default is 1.</param>
    /// <param name="pageSize">The number of items per page. Default is 10.</param>
    /// <param name="searchMode">
    /// Defines how the search term is matched. Options may include:
    /// "contains", "startsWith", or "exact". Default is "contains".
    /// </param>
    /// <returns>
    /// A task that represents the asynchronous operation. The task result contains:
    /// <list type="bullet">
    /// <item><description><c>groups</c>: A collection of <see cref="GroupModel"/> that match the search criteria.</description></item>
    /// <item><description><c>TotalCount</c>: The total number of matching groups, useful for pagination.</description></item>
    /// </list>
    /// </returns>

    Task<(IEnumerable<GroupModel> Groups, int TotalCount)> SearchGroupsAsync(
        string? searchTerm = null,
        string? sortBy = "Name",
        bool ascending = true,
        int pageNumber = 1,
        int pageSize = 10,
        string searchMode = "contains"
        );

    /// <summary>
    /// Creates a new group in the system.
    /// </summary>
    /// <param name="name">The name of the group.</param>
    /// <param name="createdByUserId">The ID of the user who created the group.</param>
    /// <param name="description">Optional description of the group.</param>
    /// <param name="category">Optional category of the group.</param>
    /// <param name="profilePicture">Optional profile picture URL for the group.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task CreateGroupAsync(string name, int createdByUserId, string? description, string? category, string? profilePicture = null);

    /// <summary>
    /// Creates a new group in the system.
    /// </summary>
    /// <param name="groupDto">The data transfer object containing group details.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task CreateGroupAsync(CreateGroupDto groupDto);

    /// <summary>
    /// Creates multiple groups in the system.
    /// </summary>
    /// <param name="groups">A list of group creation data transfer objects containing group details.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task CreateGroupsAsync(List<CreateGroupDto> groups);

    /// <summary>
    /// Creates multiple groups in the system for a specific user.
    /// </summary>
    /// <param name="userId">The unique identifier of the user creating the groups.</param>
    /// <param name="groups">A list of group creation data transfer objects containing group details.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task CreateGroupsAsync(int userId, List<CreateGroupDto> groups);

    /// <summary>
    /// Creates a new user.
    /// </summary>
    /// <param name="username">The username of the user.</param>
    /// <param name="email">The email of the user.</param>
    /// <param name="password">The password of the user.</param>
    /// <returns>The created user ID.</returns>
    Task CreateUserAsync(string username, string email, string password);

    /// <summary>
    /// Creates a new user in the system.
    /// </summary>
    /// <param name="userDto">The data transfer object containing user details.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task CreateUserAsync(CreateUserDto userDto);

    /// <summary>
    /// Creates multiple users in the system.
    /// </summary>
    /// <param name="users">A list of user creation data transfer objects containing user details.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task CreateUsersAsync(List<CreateUserDto> users);

    /// <summary>
    /// Gets a group by its ID.
    /// </summary>
    /// <param name="groupId">The group ID.</param>
    /// <returns>The group model or null if not found.</returns>
    Task<GroupModel?> GetGroupByIdAsync(int groupId);

    /// <summary>
    /// Gets a user by their ID.
    /// </summary>
    /// <param name="userId">The user ID.</param>
    /// <returns>The user model or null if not found.</returns>
    Task<UserModel?> GetUserByIdAsync(int userId);

    /// <summary>
    /// Adds a user to a group.
    /// </summary>
    /// <param name="userId">The user ID.</param>
    /// <param name="groupId">The group ID.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task AddUserToGroupAsync(int userId, int groupId);

    /// <summary>
    /// Adds multiple users to a group.
    /// </summary>
    /// <param name="userIds">A list of user IDs to add to the group.</param>
    /// <param name="groupId">The unique identifier of the group.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task AddUsersToGroupAsync(List<int> userIds, int groupId);

    /// <summary>
    /// Updates a group's details.
    /// </summary>
    /// <param name="group">The group update data transfer object containing group details.</param>
    /// <param name="groupId">The ID of the group to update.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task UpdateGroupAsync(UpdateGroupDto group, int groupId);

    /// <summary>
    /// Updates multiple groups' details.
    /// </summary>
    /// <param name="groups">A list of group update data transfer objects containing group details.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task UpdateGroupsAsync(List<BulkUpdateGroupDto> groups);

    /// <summary>
    /// Updates a user's details.
    /// </summary>
    /// <param name="user">The user update data transfer object containing user details..</param>
    /// <param name="userId">The ID of the user to update.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task UpdateUserAsync(UpdateUserDto user, int userId);

    /// <summary>
    /// Updates multiple users' details.
    /// </summary>
    /// <param name="users">A list of user update data transfer objects containing user details.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task UpdateUsersAsync(List<BulkUpdateUserDto> users);

    /// <summary>
    /// Deletes a group by its ID.
    /// </summary>
    /// <param name="groupId">The group ID.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task DeleteGroupAsync(int groupId);

    /// <summary>
    /// Deletes multiple groups by their IDs.
    /// </summary>
    /// <param name="groupIds">A list of group IDs to delete.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task DeleteGroupsAsync(List<int> groupIds);

    /// <summary>
    /// Deletes a user by their ID.
    /// </summary>
    /// <param name="userId">The user ID.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task DeleteUserAsync(int userId);

    /// <summary>
    /// Deletes multiple users by their IDs.
    /// </summary>
    /// <param name="userIds">A list of user IDs to delete.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task DeleteUsersAsync(List<int> userIds);

    /// <summary>
    /// Removes a user from a group.
    /// </summary>
    /// <param name="userId">The user ID.</param>
    /// <param name="groupId">The group ID.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    /// <remarks>This method does not delete the user or group, it only removes the association.</remarks>
    Task RemoveUserFromGroupAsync(int userId, int groupId);

    /// <summary>
    /// Removes multiple users from a group.
    /// </summary>
    /// <param name="userIds">A list of user IDs to remove from the group.</param>
    /// <param name="groupId">The unique identifier of the group.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task RemoveUsersFromGroupAsync(List<int> userIds, int groupId);

    /// <summary>
    /// Retrieves a list of groups that the specified user is a member of.
    /// </summary>
    /// <param name="userId">The unique identifier of the user.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains a list of <see cref="GroupDto"/> objects.</returns>
    Task<List<GroupResponseDto>> GetGroupsByUserId(int userId);

    /// <summary>
    /// Retrieves a list of users that are members of the specified group.
    /// </summary>
    /// <param name="groupId">The unique identifier of the group.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains a list of <see cref="UserDto"/> objects.</returns>
    Task<List<UserResponseDto>> GetUsersByGroupId(int groupId);

    /// <summary>
    /// Gets all groups.
    /// </summary>
    /// <returns>A list of all groups.</returns>
    Task<List<GroupModel>> GetAllGroupsAsync();

    /// <summary>
    /// Gets all users.
    /// </summary>
    /// <returns>A list of all users.</returns>
    Task<List<UserModel>> GetAllUsersAsync();

    /// <summary>
    /// Retrieves user count.
    /// </summary>
    /// <returns>A count of all the available users.</returns>
    Task<int> GetUserCountAsync();

    /// <summary>
    /// Gets group counts.
    /// </summary>
    /// <returns>A count of all the available groups.</returns>
    Task<int> GetGroupCountAsync();

    /// <summary>
    /// Retrieves count of users within the specified group.
    /// </summary>
    /// <param name="groupId">The unique identifier of the group.</param>
    /// <returns></returns>
    Task<int> GetUsersCountPerGroupAsync(int groupId);

    /// <summary>
    /// Retrieves user group count.
    /// </summary>
    /// <param name="userId">The unique identifier of the user.</param>
    /// <returns></returns>
    Task<int> GetUserGroupCountAsync(int userId);
}
