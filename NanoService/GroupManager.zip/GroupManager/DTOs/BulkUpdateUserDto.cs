﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupManager.DTOs
{
    /// <summary>  
    /// Represents a data transfer object for bulk updating user information.  
    /// </summary>  
    public class BulkUpdateUserDto
    {
        /// <summary>  
        /// Gets or sets the unique identifier of the user.  
        /// </summary>  
        public int Id { get; set; }

        /// <summary>  
        /// Gets or sets the username of the user.  
        /// </summary>  
        public string? UserName { get; set; }

        /// <summary>  
        /// Gets or sets the email address of the user.  
        /// </summary>  
        public string? Email { get; set; }

        /// <summary>  
        /// Gets or sets the password of the user.  
        /// </summary>  
        public string? Password { get; set; }
    }
}
