﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupManager.DTOs
{
    /// <summary>  
    /// Represents the data transfer object for updating a group.  
    /// </summary>  
    public class UpdateGroupDto
    {
        /// <summary>  
        /// Gets or sets the name of the group.  
        /// </summary>  
        public string? Name { get; set; }

        /// <summary>  
        /// Gets or sets the description of the group.  
        /// </summary>  
        public string? Description { get; set; }

        /// <summary>  
        /// Gets or sets the profile picture of the group.  
        /// </summary>  
        public string? ProfilePicture { get; set; }

        /// <summary>  
        /// Gets or sets the category of the group.  
        /// </summary>  
        public string? Category { get; set; }
    }
}
