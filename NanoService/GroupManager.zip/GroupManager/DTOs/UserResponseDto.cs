using System;

namespace GroupManager.DTOs;

/// <summary>
/// Represents the response data for a user.
/// </summary>
public class UserResponseDto
{
    /// <summary>
    /// Gets or sets the username of the user.
    /// </summary>
    public string UserName { get; set; }

    /// <summary>
    /// Gets or sets the email address of the user.
    /// </summary>
    public string Email { get; set; }
}
