﻿using GroupManager.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupManager.DTOs
{
    /// <summary>  
    /// Represents the data transfer object for creating a group.  
    /// </summary>  
    public class CreateGroupDto
    {
        /// <summary>  
        /// Gets or sets the name of the group.  
        /// </summary>  
        public required string Name { get; set; }

        /// <summary>  
        /// Gets or sets the description of the group.  
        /// </summary>  
        public string? Description { get; set; }

        /// <summary>  
        /// Gets or sets the profile picture URL of the group.  
        /// </summary>  
        public string? ProfilePicture { get; set; }

        /// <summary>  
        /// Gets or sets the ID of the user who created the group.  
        /// </summary>  
        public int CreatedByUserId { get; set; }

        /// <summary>  
        /// Gets or sets the category of the group.  
        /// </summary>  
        public string? Category { get; set; }
    }
}
