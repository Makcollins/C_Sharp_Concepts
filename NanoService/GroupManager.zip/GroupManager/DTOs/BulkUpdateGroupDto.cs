﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupManager.DTOs
{
    /// <summary>  
    /// Represents a DTO for bulk updating group information.  
    /// </summary>  
    public class BulkUpdateGroupDto
    {
        /// <summary>  
        /// Gets or sets the unique identifier of the group.  
        /// </summary>  
        public int Id { get; set; }

        /// <summary>  
        /// Gets or sets the name of the group.  
        /// </summary>  
        public string? Name { get; set; }

        /// <summary>  
        /// Gets or sets the description of the group.  
        /// </summary>  
        public string? Description { get; set; }

        /// <summary>  
        /// Gets or sets the profile picture URL of the group.  
        /// </summary>  
        public string? ProfilePicture { get; set; }
    }
}
