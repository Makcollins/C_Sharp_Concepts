using System;

namespace GroupManager.DTOs;

/// <summary>  
/// Represents the response data for a group.  
/// </summary>  
public class GroupResponseDto
{
    /// <summary>  
    /// Gets or sets the name of the group.  
    /// </summary>  
    public string Name { get; set; }

    /// <summary>  
    /// Gets or sets the description of the group.  
    /// </summary>  
    public string Description { get; set; }
}
