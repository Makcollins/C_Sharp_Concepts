﻿using GroupManager.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using NSCore.DatabaseContext;

namespace GroupManager.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddGroupManager(this IServiceCollection services, IDatabaseConfig config)
        {
            ManageGroups currentService = new ManageGroups(config);
            // Register your services here
            services.AddSingleton<IManageGroups>(provider =>
            {
                return currentService;
            });

            // Add Database connection and configure DbContext
            services.AddSingleton<IHostedService>(currentService);

            return services;
        }
    }
}
