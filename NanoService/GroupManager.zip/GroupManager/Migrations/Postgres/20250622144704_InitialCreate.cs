﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace GroupManager.Migrations.Postgres
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "__SNGroupManagerUsers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    UserName = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    Password = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    RegisteredAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK___SNGroupManagerUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "__SNGroups",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    Description = table.Column<string>(type: "text", nullable: true),
                    Category = table.Column<string>(type: "text", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    IsArchived = table.Column<bool>(type: "boolean", nullable: false),
                    IsVerified = table.Column<bool>(type: "boolean", nullable: false),
                    ProfilePicture = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    LastActivityAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    CreatedByUserId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK___SNGroups", x => x.Id);
                    table.ForeignKey(
                        name: "FK___SNGroups___SNGroupManagerUsers_CreatedByUserId",
                        column: x => x.CreatedByUserId,
                        principalTable: "__SNGroupManagerUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "__SNGroupUsers",
                columns: table => new
                {
                    GroupId = table.Column<int>(type: "integer", nullable: false),
                    UserId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK___SNGroupUsers", x => new { x.GroupId, x.UserId });
                    table.ForeignKey(
                        name: "FK___SNGroupUsers___SNGroupManagerUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "__SNGroupManagerUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK___SNGroupUsers___SNGroups_GroupId",
                        column: x => x.GroupId,
                        principalTable: "__SNGroups",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX___SNGroupManagerUsers_Email",
                table: "__SNGroupManagerUsers",
                column: "Email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX___SNGroups_CreatedByUserId",
                table: "__SNGroups",
                column: "CreatedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX___SNGroups_Name",
                table: "__SNGroups",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX___SNGroupUsers_UserId",
                table: "__SNGroupUsers",
                column: "UserId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "__SNGroupUsers");

            migrationBuilder.DropTable(
                name: "__SNGroups");

            migrationBuilder.DropTable(
                name: "__SNGroupManagerUsers");
        }
    }
}
