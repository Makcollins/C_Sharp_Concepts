# GroupManager Service

A lightweight, extensible nano service for managing groups and users. Designed for modular integration with ASP.NET Core Dependency Injection and supports multi-database setup via context initialization.

---

## ✨ Features

- Search, paginate, and sort groups with flexible query parameters
- Create, retrieve, update, and delete users and groups
- Assign users to groups and manage group memberships
- Fetch group/user counts and relationship metrics
- Plug-in architecture supporting PostgreSQL, MySQL, and SQL Server
- Built-in base controller for immediate API usage
- Supports custom controller extensions with advanced logic
- Optional background context initialization and database migrations
- Easy extension via abstract controller inheritance
---

## 📦 Installation

Set up the GroupManager service in your project using a structured flow for build, reference, and use.
#### Step 1: Register Repository in ```repos.xml```
First, make sure your project recognizes the GroupManager repository. Update your ```repos.xml``` file to include the following entry:

```bash
<Repositories>
  <Repository>
    <Name>GroupManager</Name>
    <Branch>main</Branch>
  </Repository>
</Repositories>
```



#### Step 2: Build the Service
Navigate to the build directory that contains the build.ps1 script and run the following PowerShell command:
```powershell
.\build.ps1
```

This will:

Compile the UserManager service

Copy the output DLL to build\NsStore\GroupManager.

#### Step 3: Reference the DLL in Your .csproj
```
<ItemGroup>
  <Reference Include="GroupManager">
    <HintPath>build\NsStore\GroupManager.dll</HintPath>
  </Reference>
</ItemGroup>

```

---

## Getting Started with Controllers

GroupManager includes a reusable abstract controller base with all endpoints pre-wired. Just inherit it and inject your implementation.

## Inheriting the Built-in Controller

To use the default logic and endpoints, simply extend the base controller:

```csharp
[Route("api/[controller]/[action]")]
[ApiController]
public class InheritGroupManagerController : GroupManagerControllerBase
{
    public InheritGroupManagerController(IManageGroups groupManagerHandler)
        : base(groupManagerHandler)
    {
    }
}


```
This gives you access to:
- GET search-groups
- POST create-group
- POST create-user
- GET group/{groupId}
- GET user/{userId}
- POST add-user-to-group
- PUT {groupId} and {userId}
- DELETE group/{groupId}, user/{userId}, and groups/{groupId}/users/{userId}
- GET users-in-group/{groupId}
- GET groups-for-user/{userId}
- GET all-groups and all-users
- Count endpoints like CountUsers, CountGroups, CountUsersInGroup/{groupId}, and CountGroupsForUser/{userId}

## Defining Custom Endpoints

You can extend the base controller with your own logic:

```csharp
[Route("api/[controller]/[action]")]
[ApiController]
public class InheritGroupManagerController : GroupManagerControllerBase
{
    private readonly IManageGroups _groupManagerHandler;
    public InheritGroupManagerController(IManageGroups groupManagerHandler) : base(groupManagerHandler) { }
    
    [HttpGet("all-groups")]
    public async Task<IActionResult> GetAllGroupsCustomLogic()
    {
        var groups = await _groupManagerHandler.GetAllGroupsAsync();
        return Ok(groups);
    }
}

```

## 🔧 Service Registration
In Program.cs, register the service using the provided extension:

```csharp
// SQL Server
builder.Services.AddGroupManager(IntiationModels._sqlModel);

// PostgreSQL
builder.Services.AddGroupManager(IntiationModels._psqlModel);

// MySQL
builder.Services.AddGroupManager(IntiationModels._mysqlModel);

```
***IntiationModels._psqlModel***, ***IntiationModels._sqlModel***, ***IntiationModels._mySqlModel*** must implement IDatabaseConfig and determine the correct database provider.
