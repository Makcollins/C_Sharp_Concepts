using GroupManager.Data;
using GroupManager.DbImplementation;
using GroupManager.DTOs;
using GroupManager.Interfaces;
using GroupManager.Models;
using Microsoft.Extensions.Hosting;
using NSCore.DatabaseContext;
using NSCore.DatabaseProviders;
using System.Text.RegularExpressions;
using NSCore.DatabaseContext;

namespace GroupManager;

public class ManageGroups : BackgroundService, IManageGroups
{
    private IManageGroups _connection;
    private bool _isContextCreated;
    private bool _applyMigrationsAutomatically;
    private INsContextInit _initializer;

    /// <inheritdoc/>
    public ManageGroups(IDatabaseConfig config, bool applyMigrationsAutomatically = true)
    {
        _connection = config switch { 
           SQLDb => new SQL(config.GetConnectionString()),
           PSQLDb => new PostgreSQL(config.GetConnectionString()),
           MySQLDb => new MySQL(config.GetConnectionString()),
            _ => throw new ArgumentException("Unsupported database type.")
        };
        _applyMigrationsAutomatically = applyMigrationsAutomatically;
        if (_connection == null)
            throw new InvalidOperationException("Failed to initialize a valid INsContextInit.");
        _initializer = _connection as INsContextInit ?? throw new InvalidOperationException("Failed to initialize a valid INsContextInit.");
    }

    public ManageGroups(IManageGroups connection, bool applyMigrationsAutomatically = true)
    {
        _connection = connection ?? throw new Exception("_connection is null. Make sure it's properly injected.");
        //_serviceProvider = serviceProvider;
        _applyMigrationsAutomatically = applyMigrationsAutomatically;
    }

    /// <inheritdoc/>
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (_connection == null)
        {
            throw new InvalidOperationException("Database connection is not initialized.");
        }

        if (_applyMigrationsAutomatically)
        {
            await _initializer.ApplyMigrationsAsync(stoppingToken);
        }

        if (_initializer.IsContextCreated())
        {
            _isContextCreated = true;
        }
    }
    private void EnsureContext()
    {
        if (!_isContextCreated)
        {
            throw new InvalidOperationException("Database connection is not initialized.");
        }

    }
    /// <inheritdoc/>
    public Task<(IEnumerable<GroupModel> Groups, int TotalCount)> SearchGroupsAsync(string? searchTerm = null, string? sortBy = "Name", bool ascending = true, int pageNumber = 1, int pageSize = 10, string searchMode = "contains")
    {
        EnsureContext();
        return _connection.SearchGroupsAsync(searchTerm, sortBy, ascending, pageNumber, pageSize, searchMode);
    }

    /// <inheritdoc/>
    public Task CreateGroupAsync(string name, int createdByUserId, string? description, string? category, string? profilePicture = null)
    {
        EnsureContext();
        return _connection.CreateGroupAsync(name, createdByUserId, description, category, profilePicture);
    }

    /// <inheritdoc/>
    public Task CreateGroupAsync(CreateGroupDto groupDto)
    {
        EnsureContext();
        return _connection.CreateGroupAsync(groupDto);
    }

    /// <inheritdoc/>
    public Task CreateGroupsAsync(List<CreateGroupDto> groups)
    {
        EnsureContext();
        return _connection.CreateGroupsAsync(groups);
    }

    /// <inheritdoc/>
    public Task CreateGroupsAsync(int userId, List<CreateGroupDto> groups)
    {
        EnsureContext();
        return _connection.CreateGroupsAsync(userId, groups);
    }

    /// <inheritdoc/>
    public Task CreateUserAsync(string username, string email, string password)
    {
        EnsureContext();
        return _connection.CreateUserAsync(username, email, password);
    }

    /// <inheritdoc/>
    public Task CreateUserAsync(CreateUserDto userDto)
    {
        EnsureContext();
        return _connection.CreateUserAsync(userDto);
    }

    /// <inheritdoc/>
    public Task CreateUsersAsync(List<CreateUserDto> users)
    {
        EnsureContext();
        return _connection.CreateUsersAsync(users);
    }

    /// <inheritdoc/>
    public Task<GroupModel?> GetGroupByIdAsync(int groupId)
    {
        EnsureContext();
        return _connection.GetGroupByIdAsync(groupId);
    }

    /// <inheritdoc/>
    public Task<UserModel?> GetUserByIdAsync(int userId)
    {
        EnsureContext();
        return _connection.GetUserByIdAsync(userId);
    }

    /// <inheritdoc/>
    public Task AddUserToGroupAsync(int userId, int groupId)
    {
        EnsureContext();
        return _connection.AddUserToGroupAsync(userId, groupId);
    }

    /// <inheritdoc/>
    public Task AddUsersToGroupAsync(List<int> userIds, int groupId)
    {
        EnsureContext();
        return _connection.AddUsersToGroupAsync(userIds, groupId);
    }

    /// <inheritdoc/>
    public Task UpdateGroupAsync(UpdateGroupDto group, int groupId)
    {
        EnsureContext();
        return _connection.UpdateGroupAsync(group, groupId);
    }

    /// <inheritdoc/>
    public Task UpdateGroupsAsync(List<BulkUpdateGroupDto> updatedGroups)
    {
        EnsureContext();
        return _connection.UpdateGroupsAsync(updatedGroups);
    }

    /// <inheritdoc/>
    public Task UpdateUserAsync(UpdateUserDto user, int userId)
    {
        EnsureContext();
        return _connection.UpdateUserAsync(user, userId);
    }

    /// <inheritdoc/>
    public Task UpdateUsersAsync(List<BulkUpdateUserDto> updatedUsers)
    {
        EnsureContext();
        return _connection.UpdateUsersAsync(updatedUsers);
    }

    /// <inheritdoc/>
    public Task DeleteGroupAsync(int groupId)
    {
        EnsureContext();
        return _connection.DeleteGroupAsync(groupId);
    }

    /// <inheritdoc/>
    public Task DeleteGroupsAsync(List<int> groupIds)
    {
        EnsureContext();
        return _connection.DeleteGroupsAsync(groupIds);
    }

    /// <inheritdoc/>
    public Task DeleteUserAsync(int userId)
    {
        EnsureContext();
        return _connection.DeleteUserAsync(userId);
    }

    /// <inheritdoc/>
    public Task DeleteUsersAsync(List<int> userIds)
    {
        EnsureContext();
        return _connection.DeleteUsersAsync(userIds);
    }

    /// <inheritdoc/>
    public Task RemoveUserFromGroupAsync(int userId, int groupId)
    {
        EnsureContext();
        return _connection.RemoveUserFromGroupAsync(userId, groupId);
    }

    /// <inheritdoc/>
    public Task RemoveUsersFromGroupAsync(List<int> userIds, int groupId)
    {
        EnsureContext();
        return _connection.RemoveUsersFromGroupAsync(userIds, groupId);
    }

    /// <inheritdoc/>
    public Task<List<GroupResponseDto>> GetGroupsByUserId(int userId)
    {
        EnsureContext();
        return _connection.GetGroupsByUserId(userId);
    }

    /// <inheritdoc/>
    public Task<List<UserResponseDto>> GetUsersByGroupId(int groupId)
    {
        EnsureContext();
        return _connection.GetUsersByGroupId(groupId);
    }

    /// <inheritdoc/>
    public Task<List<GroupModel>> GetAllGroupsAsync()
    {
        EnsureContext();
        return _connection.GetAllGroupsAsync();
    }

    /// <inheritdoc/>
    public Task<List<UserModel>> GetAllUsersAsync()
    {
        EnsureContext();
        return _connection.GetAllUsersAsync();
    }

    /// <inheritdoc/>
    public Task<int> GetUserCountAsync()
    {
        EnsureContext();
        return _connection.GetUserCountAsync();
    }

    /// <inheritdoc/>
    public Task<int> GetGroupCountAsync()
    {
        EnsureContext();
        return _connection.GetGroupCountAsync();
    }

    /// <inheritdoc/>
    public Task<int> GetUsersCountPerGroupAsync(int groupId)
    {
        EnsureContext();
        return _connection.GetUsersCountPerGroupAsync(groupId);
    }

    /// <inheritdoc/>
    public Task<int> GetUserGroupCountAsync(int userId)
    {
        EnsureContext();
        return _connection.GetUserGroupCountAsync(userId);
    }
}