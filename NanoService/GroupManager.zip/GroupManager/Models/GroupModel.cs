using GroupManager.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

public class GroupModel
{
    public int Id { get; set; }

    [Required]
    [StringLength(100)]
    public string Name { get; set; }

    public string? Description { get; set; }
    public string? Category { get; set; }

    public bool IsActive { get; set; } = true;
    public bool IsArchived { get; set; } = false;
    public bool IsVerified { get; set; } = false;

    public string? ProfilePicture { get; set; }

    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset UpdatedAt { get; set; }
    public DateTimeOffset? LastActivityAt { get; set; }

    public int CreatedByUserId { get; set; }
    [ForeignKey("CreatedByUserId")]
    public UserModel CreatedBy { get; set; }

    [JsonIgnore]
    public ICollection<GroupUser> GroupUsers { get; set; } = new List<GroupUser>();
}