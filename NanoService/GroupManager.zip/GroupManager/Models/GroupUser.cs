using System;

namespace GroupManager.Models;

public class GroupUser
{
    // Join table for User and Group classes
    public int GroupId { get; set; }
    public GroupModel Group { get; set; }

    public int UserId { get; set; }
    public UserModel User { get; set; }
}
