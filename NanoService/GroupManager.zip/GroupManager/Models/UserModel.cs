using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using GroupManager.Interfaces;

namespace GroupManager.Models;

public class UserModel
{
    public int Id { get; set; }

    [Required]
    [StringLength(100, ErrorMessage = "Username cannot be longer than 100 characters.")]
    [RegularExpression(@"^[a-zA-Z0-9_]+$", ErrorMessage = "Username can only contain letters, numbers, and underscores.")]
    public required string UserName { get; set; }

    [Required(ErrorMessage = "Email is required.")]
    [EmailAddress(ErrorMessage = "Invalid email address.")]
    [StringLength(255, ErrorMessage = "Email cannot be longer than 255 characters.")]
    public required string Email { get; set; }

    [Required(ErrorMessage = "Password is required.")]
    [StringLength(100, ErrorMessage = "Password cannot be longer than 100 characters.")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)] // hides it when serializing, not deserializing
    public required string Password { get; set; }

    public DateTimeOffset RegisteredAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset UpdatedAt { get; set; }

    [JsonIgnore]
    public ICollection<GroupUser> GroupUsers { get; set; } = new List<GroupUser>();
}
