using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using static GroupManager.Data.AppDbContextVariants;

namespace GroupManager.Data;

public class MySQLGroupManagerDbContextFactory : IDesignTimeDbContextFactory<MySQLGroupManagerDbContext>
{
    public MySQLGroupManagerDbContext CreateDbContext(string[] args)
    {
        var optionsBuilder = new DbContextOptionsBuilder<GroupManagerDbContext>();
        // TO-DO
        var connectionString = "Server=localhost;Database=group_manager_mysql;User=root;Password=35688410;";
        optionsBuilder.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
        return new MySQLGroupManagerDbContext(optionsBuilder.Options);
    }
}
