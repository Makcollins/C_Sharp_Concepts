using System;
using Microsoft.EntityFrameworkCore;

namespace GroupManager.Data;

public class AppDbContextVariants
{
    public class PostgresGroupManagerDbContext : GroupManagerDbContext
    {
        public PostgresGroupManagerDbContext(DbContextOptions<GroupManagerDbContext> options) : base(options) { }
    }

    public class SqlServerGroupManagerDbContext : GroupManagerDbContext
    {
        public SqlServerGroupManagerDbContext(DbContextOptions<GroupManagerDbContext> options) : base(options) { }
    }

    public class MySQLGroupManagerDbContext : GroupManagerDbContext
    {
        public MySQLGroupManagerDbContext(DbContextOptions<GroupManagerDbContext> options) : base(options) { }
    }
}
