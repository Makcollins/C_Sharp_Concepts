using System;
using System.Text.RegularExpressions;
using GroupManager.Models;
using Microsoft.EntityFrameworkCore;
using NSCore.DatabaseProviders;

namespace GroupManager.Data;

public class GroupManagerDbContext : DbContext
{
    private readonly string? _connectionString;
    private readonly DbProvider _dbProvider;

    public GroupManagerDbContext(DbContextOptions<GroupManagerDbContext> options) : base(options)
    {
    }

    public GroupManagerDbContext(string connectionString, DbProvider dbProvider)
    {
        _connectionString = connectionString;
        _dbProvider = dbProvider;
    }

    /// <inheritdoc/>
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured && _connectionString != null)
        {
            switch (_dbProvider)
            {
                case DbProvider.SqlServer:
                    optionsBuilder.UseSqlServer(_connectionString);
                    break;
                case DbProvider.PostgreSQL:
                    optionsBuilder.UseNpgsql(_connectionString);
                    break;
                case DbProvider.MySQL:
                    optionsBuilder.UseMySql(_connectionString, ServerVersion.AutoDetect(_connectionString));
                    break;
                default:
                    throw new ArgumentOutOfRangeException($"Unsupported database provider: {_dbProvider}");
            }
        }
    }

    /// <inheritdoc/>
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<UserModel>(entity =>
        {
            entity.ToTable("__SNGroupManagerUsers");
            entity.HasKey(u => u.Id);
            entity.HasIndex(u => u.Email).IsUnique();
        });

        modelBuilder.Entity<GroupModel>(entity =>
        {
            entity.ToTable("__SNGroups");
            entity.HasKey(g => g.Id);
            entity.HasIndex(g => g.Name).IsUnique();
        });

        modelBuilder.Entity<GroupUser>(entity =>
        {
            entity.ToTable("__SNGroupUsers");
            entity.HasKey(gu => new { gu.GroupId, gu.UserId });

            entity.HasOne(gu => gu.Group)
                  .WithMany(g => g.GroupUsers)
                  .HasForeignKey(gu => gu.GroupId)
            .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(gu => gu.User)
                  .WithMany(u => u.GroupUsers)
                  .HasForeignKey(gu => gu.UserId)
            .OnDelete(DeleteBehavior.Restrict);
        });

        base.OnModelCreating(modelBuilder);
    }

    public DbSet<GroupModel> Groups { get; set; }
    public DbSet<UserModel> Users { get; set; }
    public DbSet<GroupUser> GroupUsers { get; set; }
}
