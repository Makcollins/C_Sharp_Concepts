using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using static GroupManager.Data.AppDbContextVariants;

namespace GroupManager.Data;

public class PostgresGroupManagerDbContextFactory : IDesignTimeDbContextFactory<PostgresGroupManagerDbContext>
{
    public PostgresGroupManagerDbContext CreateDbContext(string[] args)
    {
        var optionsBuilder = new DbContextOptionsBuilder<GroupManagerDbContext>();
        var connectionString = "Host=localhost;Port=5432;Database=group_manager_pg;Username=postgres;Password=35688410;";
        optionsBuilder.UseNpgsql(connectionString);
        return new PostgresGroupManagerDbContext(optionsBuilder.Options);
    }
}
