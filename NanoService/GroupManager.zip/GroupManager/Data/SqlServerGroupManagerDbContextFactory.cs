using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using static GroupManager.Data.AppDbContextVariants;

namespace GroupManager.Data;

public class SqlServerGroupManagerDbContextFactory : IDesignTimeDbContextFactory<SqlServerGroupManagerDbContext>
{
    public SqlServerGroupManagerDbContext CreateDbContext(string[] args)
    {
        var optionsBuilder = new DbContextOptionsBuilder<GroupManagerDbContext>();
        // var connectionString = "Server=localhost;Database=file_manager_sql;User Id=sa;Password=yourpassword;";
        var connectionString = "Server=localhost;Database=group_manager_sql;Trusted_Connection=True;TrustServerCertificate=True;";
        optionsBuilder.UseSqlServer(connectionString);
        return new SqlServerGroupManagerDbContext(optionsBuilder.Options);
    }
}
