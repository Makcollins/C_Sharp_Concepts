﻿using GroupManager.DTOs;
using GroupManager.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace GroupManager.Controllers
{
    public abstract class GroupManagerControllerBase : ControllerBase
    {
        private readonly IManageGroups _groupManagerHandler;
        public GroupManagerControllerBase(IManageGroups groupManagerHandler)
        {
            _groupManagerHandler = groupManagerHandler ?? throw new ArgumentNullException(nameof(groupManagerHandler));
        }

        [HttpGet("search-groups")]
        public async Task<IActionResult> SearchGroupsAsync(
             [FromQuery] string? searchTerm = null,
             [FromQuery] string? sortBy = "Name",
             [FromQuery] bool ascending = true,
             [FromQuery] int pageNumber = 1,
             [FromQuery] int pageSize = 3,
             [FromQuery] string searchMode = "contains")
        {
            {
                var (groups, totalCount) = await _groupManagerHandler.SearchGroupsAsync(
                    searchTerm, sortBy, ascending, pageNumber, pageSize, searchMode);

                return Ok(new
                {
                    TotalCount = totalCount,
                    Groups = groups
                });
            }
        }

        [HttpPost("create-group")]
        public async Task<IActionResult> CreateGroup([FromBody] CreateGroupDto dto)
        {
            await _groupManagerHandler.CreateGroupAsync(dto.Name, dto.CreatedByUserId, dto.Description, dto.Category, dto.ProfilePicture);
            return Ok();
        }

        [HttpPost("create-user")]
        public async Task<IActionResult> CreateUser([FromBody] CreateUserDto dto)
        {
            await _groupManagerHandler.CreateUserAsync(dto.UserName, dto.Email, dto.Password);
            return Ok();
        }

        [HttpGet("group/{groupId}")]
        public async Task<IActionResult> GetGroupById(int groupId)
        {
            var group = await _groupManagerHandler.GetGroupByIdAsync(groupId);
            if (group == null) return NotFound();
            return Ok(group);
        }

        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetUserById(int userId)
        {
            var user = await _groupManagerHandler.GetUserByIdAsync(userId);
            if (user == null) return NotFound();
            return Ok(user);
        }

        [HttpPost("add-user-to-group")]
        public async Task<IActionResult> AddUserToGroup(int userId, int groupId)
        {
            await _groupManagerHandler.AddUserToGroupAsync(userId, groupId);
            return Ok();
        }

        [HttpPut("{groupId}")]
        public async Task<IActionResult> UpdateGroup([FromBody] UpdateGroupDto group, int groupId)
        {
            await _groupManagerHandler.UpdateGroupAsync(group, groupId);
            return Ok();
        }

        [HttpPut("{userId}")]
        public async Task<IActionResult> UpdateUser([FromBody] UpdateUserDto user, int userId)
        {
            await _groupManagerHandler.UpdateUserAsync(user, userId);
            return Ok();
        }

        [HttpDelete("group/{groupId}")]
        public async Task<IActionResult> DeleteGroup(int groupId)
        {
            await _groupManagerHandler.DeleteGroupAsync(groupId);
            return NoContent();
        }

        [HttpDelete("user/{userId}")]
        public async Task<IActionResult> DeleteUser(int userId)
        {
            await _groupManagerHandler.DeleteUserAsync(userId);
            return NoContent();
        }

        [HttpDelete("groups/{groupId}/users/{userId}")]
        public async Task<IActionResult> RemoveUserFromGroup(int groupId, int userId)
        {
            await _groupManagerHandler.RemoveUserFromGroupAsync(userId, groupId);
            return Ok(new { message = $"User {userId} removed from group {groupId}." });
        }


        [HttpGet("users-in-group/{groupId}")]
        public async Task<IActionResult> GetUsersByGroupId(int groupId)
        {
            var users = await _groupManagerHandler.GetUsersByGroupId(groupId);
            return Ok(users);
        }

        [HttpGet("groups-for-user/{userId}")]
        public async Task<ActionResult<ICollection<GroupResponseDto>>> GetGroupsByUserId(int userId)
        {
            var groups = await _groupManagerHandler.GetGroupsByUserId(userId);
            return Ok(groups);
        }

        [HttpGet("all-groups")]
        public async Task<IActionResult> GetAllGroups()
        {
            var groups = await _groupManagerHandler.GetAllGroupsAsync();
            return Ok(groups);
        }

        [HttpGet("all-users")]
        public async Task<IActionResult> GetAllUsers()
        {
            var users = await _groupManagerHandler.GetAllUsersAsync();
            return Ok(users);
        }


        [HttpGet("CountUsers")]
        public async Task<ActionResult<int>> GetUserCountAsync()
        {
            var count = await _groupManagerHandler.GetUserCountAsync();
            return Ok(count);
        }

        [HttpGet("CountGroups")]
        public async Task<ActionResult<int>> GetGroupCountAsync()
        {
            var count = await _groupManagerHandler.GetGroupCountAsync();
            return Ok(count);
        }

        [HttpGet("CountUsersInGroup/{groupId}")]
        public async Task<ActionResult<int>> GetUserCountInGroupAsync(int groupId)
        {
            var count = await _groupManagerHandler.GetUsersCountPerGroupAsync(groupId);
            return Ok(count);
        }

        [HttpGet("CountGroupsForUser/{userId}")]
        public async Task<ActionResult<int>> GetGroupCountForUserAsync(int userId)
        {
            var count = await _groupManagerHandler.GetUserGroupCountAsync(userId);
            return Ok(count);
        }
    }
}
