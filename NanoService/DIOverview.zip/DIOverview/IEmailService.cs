using System;

namespace DIOverview;

public interface IEmailService
{
    string GetMessage();
}
