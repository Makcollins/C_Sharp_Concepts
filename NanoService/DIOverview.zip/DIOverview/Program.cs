﻿using System.ComponentModel.Design;
using Microsoft.Extensions.DependencyInjection;

namespace DIOverview;

public class Program
{
    // Build your service provider
    static void Main(string[] args)
    {
        var serviceProvider = new ServiceCollection()
        .AddScoped<IEmailService, EmailService>() // register emails service and its implementation
        .AddScoped<Notification>()
        .BuildServiceProvider(); // register Notification class

        // resolve service
        var notification = serviceProvider.GetRequiredService<Notification>();

        // use resolved service
        notification.SendMessage();
    }
}