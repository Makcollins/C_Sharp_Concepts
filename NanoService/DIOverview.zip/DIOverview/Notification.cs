using System;

namespace DIOverview;

public class Notification
{
    private readonly IEmailService _emailService;

    public Notification(IEmailService emailService)
    {
        // var service = new EmailService();
        _emailService = emailService ?? throw new ArgumentNullException(nameof(emailService));
        // _emailService = service;
    }

    public void SendMessage()
    {
        System.Console.WriteLine(_emailService.GetMessage());
    }
}
