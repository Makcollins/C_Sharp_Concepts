using System;

namespace DIOverview;

public class EmailService : IEmailService
{
    public string GetMessage()
    {
        return "This is an email message";
    }
}
