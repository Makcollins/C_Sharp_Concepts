using System;

namespace Test
{
    class Template
    {
        // static void Main(string[] args)
        // {
        //     Console.WriteLine("Mak");
        // }
    }
}