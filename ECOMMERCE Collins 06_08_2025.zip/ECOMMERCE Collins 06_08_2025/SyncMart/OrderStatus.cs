namespace SyncMart;

public enum OrderStatus
{
Ordered, Cancelled
}
