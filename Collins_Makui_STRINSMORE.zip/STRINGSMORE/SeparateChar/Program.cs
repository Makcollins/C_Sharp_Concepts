﻿using System;

namespace SeparateChar
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "Syncfusion Software";

            foreach (char ch in s)
            {
                Console.WriteLine(ch);
            }

        }
    }

}