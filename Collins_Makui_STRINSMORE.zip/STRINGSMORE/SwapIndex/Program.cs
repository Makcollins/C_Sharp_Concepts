﻿// using System;

// namespace CompareLastName
// {
//     class Program
//     {
//         static void Main(string[] args)
//         {
//             string s = "codekata";
//             string newS = "";

//             int temp = 0;

//             for (int i = 0; i < s.Length; i++)
//             {
//                 if (i % 2 != 1)
//                 {
//                    Console.Write(s[i+1]);
//                 }
//                 else
//                 {
//                     Console.Write(s[i-1]);
//                 }
//             }
//         }
//     }

// }