﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ListDS
{
    class Program
    {
        static void Main(string[] args)
        {
            if (!Directory.Exists("TestFolder"))
            {
                Directory.CreateDirectory("TestFolder");
                 System.Console.WriteLine("Folder created");
            }
            else { System.Console.WriteLine("Folder Found"); }

            if (!File.Exists("TestFolder/Data.csv"))
            {
                Console.WriteLine("File doesn't exist. Creating a new CSV file");
                File.Create("TestFolder/Data.csv").Close();
            }
            else { Console.WriteLine("File found"); }

            List<Student> vlist = new List<Student>();
            vlist.Add
            (
                new Student()
                {
                    Name = "Ravi",  FatherName = "Ettapparajan",
                    Gender = Gender.Male,  DOB = new DateTime(1999, 11, 11),
                    TotalMark = 280
                }
            );
            vlist.Add(new Student()
            {
                Name = "Baskaran", FatherName = "Sethurajan",
                Gender = Gender.Male,   DOB = new DateTime(1996, 11, 11),
                TotalMark = 260
            });
            vlist.Add(new Student()
            {
                Name = "Sandhya",  FatherName = "Rajendran",
                Gender = Gender.Male,  DOB = new DateTime(1997, 11, 11),
                TotalMark = 270
            });
            Insert(vlist);
            Display();
            Update();
        }
        static void Insert(List<Student> vlist)
        {
            StreamWriter write = new StreamWriter(File.OpenWrite("TestFolder/Data.csv"));
            foreach (Student student in vlist)
            {
                 //Write an object's information to file by making property data as a string and putting "," 
                write.WriteLine(student.Name + "," + student.FatherName + "," + student.Gender
                 + "," + student.DOB.ToString("dd/MM/yyyy") + "," + student.TotalMark);
            }
            write.Close();
        }
        static void Display()
        {
            StreamReader reader = null;
            List<Student> listA = new List<Student>(); //List to store data from file
            if (File.Exists("TestFolder/Data.csv"))
            {
                reader = new StreamReader(File.OpenRead("TestFolder/Data.csv")); // Open file for reading
                while (!reader.EndOfStream) // Check end of file not reached
                {
                    string line = reader.ReadLine(); // Read one line from file
                    string[] values = line.Split(',');// Split that line and form as an array
                    if (values[0] != "") // Check the line has valid data
                    {
                        listA.Add
                        (   new Student() // Create Student object with file read values and add to list
                            {
                            Name = values[0],   FatherName = values[1], Gender = Enum.Parse<Gender>(values[2]),
                            DOB = DateTime.ParseExact(values[3], "dd/MM/yyyy", null),
                            TotalMark = double.Parse(values[4])
                            }
                        );
                    }
                }
            }
            else
            { Console.WriteLine("File doesn't exist"); }
            reader.Close(); // Close the file
            foreach (Student student in listA) // Show the read information from file in console
            { Console.WriteLine("Your Name:\t" + student.Name + "\t Father Name:\t" + student.FatherName +
                 "\t Gender is:\t"+ student.Gender + "\t DOB: \t" + student.DOB.ToString("dd/MM/yyyy") 
                 + "\t Total Mark" + student.TotalMark);
            }
        }
        static void Update()
        {
            Console.WriteLine("To update Select option 0.your name 1. Father name ");
            int option = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the name to be updated");
            string name = Console.ReadLine();

            string[] lines = File.ReadAllLines("Data.csv");// Read file and make it as array
            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i] != "")
                {
                    var values = lines[i].Split(','); // Read a object line string and make it as array
                    if (values[option] == name)// check the name is matching
                    {
                        Console.WriteLine("Enter new name to update");
                        string name1 = Console.ReadLine();

                        if (option == 0)
                        {
                            lines[i] = name1 + "," + values[1] + "," + values[2] + "," + values[3];
                        }
                        else if (option == 1)
                        {
                            lines[i] = values[0] + "," + name1 + "," + values[2] + "," + values[3];
                        }
                    }
                }
            }
            File.WriteAllLines("Data.csv", lines);
        }
    }
}
