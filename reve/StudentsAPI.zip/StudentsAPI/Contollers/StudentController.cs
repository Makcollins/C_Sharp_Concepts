using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentsAPI.Data;
using StudentsAPI.Models;

namespace StudentsAPI.Contollers
{
    [Route("api/students")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly StudentDbContext _context;

        public StudentController(StudentDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        // GET  api/students
        [HttpGet]
        public async Task<ActionResult<List<Student>>> GetAllStudents()
        {
            var students = await _context.Students.ToListAsync();
            return Ok(students);
        }

        // GET  api/students/id
        [HttpGet("{id}")]
        public async Task<ActionResult<Student>> GetStudentById(int id)
        {
            var student = await _context.Students.FindAsync(id);
            if (student == null)
            {
                return NotFound(new { error = $"Student with ID {id} not found." });
            }
            return Ok(student);
        }

        // POST api/students
        [HttpPost]
        public async Task<IActionResult> AddStudent([FromBody] Student newStudent)
        {
            if (newStudent == null)
            {
                return BadRequest();
            }

            _context.Students.Add(newStudent);
            await _context.SaveChangesAsync();
            // return Created();
            return CreatedAtAction(nameof(GetStudentById), new { id = newStudent.Id }, newStudent);
        }

        // PATCH api/students/id
        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateStudent(int id, [FromBody] Student updateStudent)
        {
            if (id < 1)
            {
                throw new ArgumentException("ID cannot be less than 1");
            }
            try
            {
                var existingStudent = await _context.Students.FirstOrDefaultAsync(s => s.Id == id);

                existingStudent.Name = updateStudent.Name?.Trim() ?? existingStudent.Name;
                existingStudent.Age = (updateStudent.Age == existingStudent.Age) ? existingStudent.Age : updateStudent.Age;
                existingStudent.Email = updateStudent.Email?.Trim() ?? existingStudent.Email;

                _context.Students.Update(existingStudent);
                await _context.SaveChangesAsync();
                return NoContent();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        // DELETE api/students/id
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStudent(int id)
        {
            if (id < 1)
            {
                throw new ArgumentException("ID cannot be less than 1");
            }

            var student = await _context.Students.FindAsync(id);

            if (student == null)
            {
                return NotFound();
            }

            _context.Students.Remove(student);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
