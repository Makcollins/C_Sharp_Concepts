using System;
using System.ComponentModel.DataAnnotations;

namespace StudentsAPI.Models;

public class Student
{
    [Key]
    [Required]
    public int Id { get; set; }

    [Length(minimumLength:2, maximumLength:20, ErrorMessage ="Name must have at least 2 characters")]
    public string Name { get; set; }
    public int Age { get; set; }
    
    [EmailAddress(ErrorMessage ="Invalid email")]
    public string Email { get; set; }
}
