using System;
using Microsoft.EntityFrameworkCore;
using StudentsAPI.Models;

namespace StudentsAPI.Data;

public sealed class StudentDbContext : DbContext
{
    public DbSet<Student> Students { get; set; }

    private StudentDbContext(DbContextOptions<StudentDbContext> options) : base(options) { }

}


